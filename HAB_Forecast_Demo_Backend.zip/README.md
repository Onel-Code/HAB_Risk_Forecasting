# Historical Forecast Demo: Backend Add-on

This keeps your existing `POST /predict` and `GET /health` routes while adding `POST /evaluate` for a **preselected group of exactly 10 historical test cases**.

## Copy files into GitHub Codespaces

From the ZIP, copy:

- `backend/ml_api.py` over your existing `backend/ml_api.py` **after backing up the old one**.
- `backend/demo_evaluate.py` to `backend/demo_evaluate.py`.
- `backend/historical_10_case_template.csv` to a convenient path and fill it with **10 preselected, genuinely held-out historical records**.

Do **not** overwrite your existing `backend/models/xgb_fusion_exploratory.json`. It is the trained model. This package does not include the trained model or actual verified ten-case labels.

## Run backend

```bash
python -m uvicorn backend.ml_api:app --host 0.0.0.0 --port 8000 --reload
```

Open `http://127.0.0.1:8000/docs` or the forwarded Codespaces port 8000 to test `/health`, `/predict` and `/evaluate`.

## Prepare the ten-case CSV

Column descriptions:

- `case_id`: your unique historical record/station-month ID
- `month`: **input observation month**, `YYYY-MM`; the API forecasts the next month
- `temperature_c_median`, `pH_median`, `DO_mg_l_median`, `insitu_chl_a_ug_l_median`, `satellite_chl_monthly_median`: actual numeric feature values; do **not** invent or fill invalid satellite values with arbitrary numbers
- `actual_bloom`: independently recorded outcome in the **following month** (`1` observed bloom, `0` confirmed no-bloom). For a proxy evaluation, explicitly mark it as proxy and explain the criterion.
- `label_type`: `verified` for independently supported outcomes; `proxy` for proxy-derived labels. Do not mark unconfirmed absences `verified`.

Select the ten rows *before looking at the model predictions*, and only from a set kept out of training. The API cannot check whether that was actually done.

## Evaluate from terminal

```bash
python backend/demo_evaluate.py backend/models/heldout_10_cases.csv
```

The script calls the existing running API and prints each prediction, the supplied historical outcome, the actual score out of ten, and the always-bloom baseline. It will **not** manufacture test labels or a target 6/10 result.

## Limitations that must be disclosed

1. Your current model requires **in-situ chlorophyll-a** and **monthly satellite chlorophyll-related values** in addition to water temperature, pH, and DO. Your planned ESP32 sensor suite does not measure chlorophyll-a; the model currently supports an offline practice/demo path, not end-to-end field forecasting.
2. Your current `month` field changes only the **forecast display month**. It is **not an XGBoost input feature** in the existing trained model; changing the month while keeping all numerical values fixed produces the same probability.
3. A score based on proxy outcomes is **proxy-label agreement**, not verified HAB prediction accuracy. Without toxin labels, the system does not validate harmfulness.
4. Even 6/10 is not sufficient by itself to demonstrate a useful model. Compare against the always-bloom baseline, use a larger untouched test set when possible, and report uncertainty.
5. There is no Firebase writer in this package: this code adds evaluation to your current API only. The React/Firestore integration should be performed against your actual frontend source next.
